/* imports ... */
public class PredictionsHttpsClient {
    private static final String endpoint = "https://localhost:8443/predictions2HTTPS";
    private static final String truststore = "test.keystore";  //*** same file as TOMCAT_HOME/conf/certs/tcat.keystore

    public static void main(String[ ] args) {
	new PredictionsHttpsClient().runTests();
    }
    private void runTests() {
	try {
	    //*** start of setup code: could be done from command-line with properties
	    SSLContext sslCtx = SSLContext.getInstance("TLS");
	    char[ ] password = "qubits".toCharArray();
	    KeyStore ks = KeyStore.getInstance("JKS");
	    FileInputStream fis = new FileInputStream(truststore);
	    ks.load(fis, password);
	    TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
	    tmf.init(ks);                       //*** same as keystore
	    sslCtx.init(null,                   //*** keystore not needed, as client is not challenged
			tmf.getTrustManagers(), 
			new SecureRandom());                
	    HttpsURLConnection.setDefaultSSLSocketFactory(sslCtx.getSocketFactory());
	    //*** end of setup code

	    getTest();
	    postTest();
            /** other tests **/
	}
	catch(Exception e) { throw new RuntimeException(e); }
    }
    private HttpsURLConnection getConnection(URL url, String verb) {
        /* ... */
    }
    /** ... **/

