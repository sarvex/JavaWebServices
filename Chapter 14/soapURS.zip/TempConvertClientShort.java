/* imports... */
public class TempConvertClient {
    private static final String endpoint = "https://localhost:8443/tc";
    static {
	/* ... */
	try {
	    TrustManager[ ] trustMgr = new TrustManager[ ] {                              /** line 1 **/
		new X509TrustManager() {
		    public X509Certificate[ ] getAcceptedIssuers() { return null; }       /** line 2 **/
		    public void checkClientTrusted(X509Certificate[ ] cs, String t) { }   /** line 3 **/
		    public void checkServerTrusted(X509Certificate[ ] cs, String t) { }   /** line 4 **/
		}
	    };
	    SSLContext sslCtx = SSLContext.getInstance("TLS");
	    sslCtx.init(null, trustMgr, null);
	    HttpsURLConnection.setDefaultSSLSocketFactory(sslCtx.getSocketFactory());
	}
	catch(Exception e) { throw new RuntimeException(e); }
    }
    public static void main(String args[ ]) {
	/* ... */
        TempConvert port = new TempConvertService().getTempConvertPort();
	BindingProvider prov = (BindingProvider) port;                                    /** line 5 **/
	
	prov.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
	prov.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, uname);           /** line 6 **/
        prov.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, passwd);          /** line 7 **/
	/* javax.xml.ws.security.auth.username
	   javax.xml.ws.security.auth.password */
        System.out.println("f2c(-40.1) = " + port.f2C(-40.1f));
	/* ... */
    }
}
