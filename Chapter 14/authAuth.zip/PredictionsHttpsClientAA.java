/* imports */
public class PredictionsHttpsClientAA {
    private static final String endpoint = "https://localhost:8443/predictions2AA"; /** line 1 **/
    private static final String truststore = "test.keystore";

    public static void main(String[ ] args) {
	new PredictionsHttpsClientAA().runTests();
    }
    private void runTests() {
	try {
	    SSLContext sslCtx = SSLContext.getInstance("TLS");                  /** line 2 **/
	    char[ ] password = "qubits".toCharArray();
	    KeyStore ks = KeyStore.getInstance("JKS");
	    FileInputStream fis = new FileInputStream(truststore);
	    ks.load(fis, password);
	    TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
	    tmf.init(ks); // same as keystore
	    sslCtx.init(null,                   // not needed, not challenged
			tmf.getTrustManagers(), 
			new SecureRandom());                
	    HttpsURLConnection.setDefaultSSLSocketFactory(sslCtx.getSocketFactory());

	    // Proof of concept tests.
	    String uname = "moe";                                               /** line 3 **/
	    String passwd = "MoeMoeMoe";
	    getTest(uname, passwd);
            /* ... other tests */
    }

    private HttpsURLConnection getConnection(URL url,                           /** line 4 **/
				             String verb, 
			        	     String uname, 
					     String passwd) {
	try {	
	    HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
	    conn.setDoInput(true);
	    conn.setDoOutput(true);
	    conn.setRequestMethod(verb);
	    
	    // authentication (although header name is Authorization)           /** line 5 **/
	    String userpass = uname + ":" + passwd;
	    String basicAuth = "Basic " +                                       /** line 6 **/
		new String(new Base64().encode(userpass.getBytes()));
	    conn.setRequestProperty ("Authorization", basicAuth);               /** line 7 **/
	    /* ... */

